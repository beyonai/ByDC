"""DDL SQL resources."""
