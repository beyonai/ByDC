"""Seed SQL resources."""
