"""Seed SQL resources."""
